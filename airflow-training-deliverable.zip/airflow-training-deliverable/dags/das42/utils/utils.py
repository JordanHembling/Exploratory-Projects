
class Utils:
    def __init__(self):
        pass